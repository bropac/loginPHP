<!doctype html>
<br>
    <body>
    <link rel="stylesheet" href="fileCSS/homePage.css" type="text/css">
    <?php
        session_start();

        if (isset($_SESSION['in_username']) && isset($_SESSION['in_password']))
        {
            $in_username = $_SESSION['in_username'];
        }
        else
        {
            header("Location: index.php");
        }
        
    ?>
    <div id="divTop" style="text-align:center">
    <?php
    $in_date = $_SESSION['in_date'];
        echo  $in_username;
        
    ?>
        <input type="button" id="buttonHomeId" class="buttonHomePlayAbout" onclick="location.href='homePage.php';" value="Home">
        <input type="button" id="buttonEditId" class="buttonEditLogout" onclick="location.href='editProfile.php';" value="Edit">
        <input type="button" id="buttonLogoutId" class="buttonEditLogout" onclick="location.href='logout.php';" value="Logout">
    </div>

    <div id="divTopButton"></div>

    <div id="divMainPage">
    </div>
    
    <?php
    
    ?>
    </body>
</html>