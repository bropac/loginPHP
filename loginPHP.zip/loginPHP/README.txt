Semplice pagina di login tramite l'utilizzo dei linguaggi di programmazione PHP,HTML,CSS e SQL, e dei servizi di Apache e database MySQL, tutto eseguito in locale.
L'utente inserisce le proprie credenziali e accede alla pagina principale. Se non � ancora registrato, pu� farlo inserendo username univoco, password e data di nascita. All'interno del suo profilo esiste una homepage, una pagina dove pu� modificare data di nascita e username oppure eliminare il proprio profilo.
L'applicazione si basa sull'utilizzo principalmente dei metodi POST e SESSION, utilizzati soprattutto per controllare che l'utente possa eseguire in modo sicuro il login e il logout senza problemi.

Programmi essenziali

- XAMPP con i servizi Apache e MySQL
- Editor di codice (es. Visual Studio Code)